import { useState } from 'react';

const firmwareData = [
  {
    item: 'Redeployable Camera',
    make: 'Hikvision',
    model: 'DS-2DF8236IX-AELW',
    currentFw: 'V5.6.0',
    latestFw: 'v5.6.0 build 190320',
    firmwareAge: 'Very Old',
    downloadUrl: 'https://www.hikvision.com/en/support/download/firmware/ptz-camera/'
  },
  {
    item: 'Switch Port',
    make: 'Ubiquiti',
    model: 'ES-8-150W',
    currentFw: 'V1.4.1',
    latestFw: 'v1.11.0-lite',
    firmwareAge: 'Up to Date',
    downloadUrl: 'https://ui.com/download/edgemax/edgeswitch-8-150w'
  }
];

const ageColor = {
  'Very Old': 'bg-red-200 text-red-800',
  'Old': 'bg-yellow-200 text-yellow-800',
  'Up to Date': 'bg-green-200 text-green-800',
  'Unknown': 'bg-gray-200 text-gray-800'
};

export default function Home() {
  const [search, setSearch] = useState('');

  const filteredData = firmwareData.filter((entry) =>
    Object.values(entry).some((val) => val.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-4 max-w-screen-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Firmware Asset Tracker</h1>
      <input
        placeholder="Search make, model, version..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-4 p-2 border rounded w-full"
      />
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-100 text-left">
            <th className="p-2 border">Item</th>
            <th className="p-2 border">Make</th>
            <th className="p-2 border">Model</th>
            <th className="p-2 border">Current FW</th>
            <th className="p-2 border">Latest FW</th>
            <th className="p-2 border">Firmware Age</th>
            <th className="p-2 border">Download</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((entry, idx) => (
            <tr key={idx} className="border-t">
              <td className="p-2 border">{entry.item}</td>
              <td className="p-2 border">{entry.make}</td>
              <td className="p-2 border">{entry.model}</td>
              <td className="p-2 border">{entry.currentFw}</td>
              <td className="p-2 border">{entry.latestFw}</td>
              <td className={`p-2 border ${ageColor[entry.firmwareAge] || ''}`}>{entry.firmwareAge}</td>
              <td className="p-2 border">
                <a href={entry.downloadUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                  Download
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
