# Firmware Tracker

This is a simple firmware asset tracking web tool built with Next.js.
